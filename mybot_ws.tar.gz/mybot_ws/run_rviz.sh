#!/bin/bash

roslaunch mybot_description mybot_rviz.launch 
