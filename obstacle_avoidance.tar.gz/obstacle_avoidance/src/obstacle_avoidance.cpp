#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Float32.h>
#include <sensor_msgs/LaserScan.h>
#include <iostream>
#include <tf/tfMessage.h>
#include <tf/transform_datatypes.h>
#include <cmath>

class BotController{
    private:
        ros::Subscriber sub_scan;
        ros::Subscriber pos_sub;
        ros::Publisher vel_pub;
        ros::Publisher error_forward_pub;
        ros::Publisher error_angle_pub;
        ros::Publisher control_signal_forward_pub;
        ros::Publisher control_signal_angle_pub;
        std::vector<float> scan_vector;
        double trans_x, trans_z;
        double pos_x, pos_y, ori_z, ang_z;
        double target_distance, target_angle;
        double init_r, init_ang_z, init_x, init_y;
        double dt;
        float scan_middle;
        int Kp_forward, Ki_forward, Kd_forward, Kp_angle, Ki_angle, Kd_angle;
        double error_forward, error_angle, error_forward_prev, error_angle_prev;
        double PI_;
        double I_angle, D_angle, I_forward, D_forward;

    public:
        BotController(ros::NodeHandle &nh){
            trans_x = 0;
            trans_z = 0;
            error_forward = 0;
            error_angle = 0;
            error_forward_prev = 0;
            error_angle_prev = 0;
            target_distance = 1;// Change target distance
            target_angle = 0;// Change target angle
            dt = 0.1;
            PI_ = 3.1415;
            I_angle = 0;
            D_angle = 0;
            I_forward = 0;
            D_forward = 0;
            pos_sub = nh.subscribe("/odom",1,&BotController::callback, this);
            sub_scan = nh.subscribe("/scan", 1, &BotController::callback_range_finder, this);
            vel_pub = nh.advertise<geometry_msgs::Twist>("/mobile_base/commands/velocity",1);
            error_forward_pub = nh.advertise<std_msgs::Float32>("/error_forward",1);
            error_angle_pub = nh.advertise<std_msgs::Float32>("/error_angle",1);
            control_signal_forward_pub = nh.advertise<std_msgs::Float32>("/control_signal_forward",1);
            control_signal_angle_pub = nh.advertise<std_msgs::Float32>("/control_signal_angle",1);
        }

        void callback( const nav_msgs::OdometryConstPtr& poseMsg){
            pos_x = poseMsg->pose.pose.position.x;
            pos_y = poseMsg->pose.pose.position.y;
            ori_z = poseMsg->pose.pose.orientation.z;
            ang_z = ori_z*2.19;
        }

        void callback_range_finder(const sensor_msgs::LaserScan::ConstPtr& scanMsg){
          scan_vector = scanMsg->ranges;
          int scan_vector_middle_index = (int)round(scan_vector.size() / 2.0);
          scan_middle = scan_vector[scan_vector_middle_index];
          moveforward();
        }

        void moveforward(){
          geometry_msgs::Twist base_cmd;
          std_msgs::Float32 linear_error;
          std_msgs::Float32 angular_error;
          std_msgs::Float32 linear_velocity;
          std_msgs::Float32 angular_velocity;

          error_forward_prev = error_forward;
          error_angle_prev = error_angle;
          error_forward = scan_middle - target_distance;
          error_angle = ori_z - target_angle;


          if (error_angle < -PI_)
          {
              error_angle += 2*PI_;
          }
          if (error_angle >= PI_)
          {
              error_angle -= 2*PI_;
          }

          //Integral term in PID controller
          I_forward += dt * error_forward;
          I_angle += dt * error_angle;

          //Derivative term in PID Controller
          D_forward = error_forward_prev - error_forward;
          D_angle = error_angle_prev - error_angle;

          if(isnan(scan_middle)){
            trans_x = 0.5;
          }
          else
          {
            if(error_forward > 0.2){
                trans_x = error_forward + 2 * D_forward;//*dist; // Change robot velocity
            }else if(error_forward < - 0.2){
              trans_x = - error_forward - 2 * D_forward;
            }else{
                trans_x = 0;
            }
          }

          // Set the treshold
          if(trans_x > 0.6){
            trans_x = 0.6;
          }
          if(trans_x < -0.6){
            trans_x = - 0.6;
          }

          if(error_angle < -0.01){
            trans_z =  -5 * error_angle + -10 * D_angle;
          }else if(error_angle > 0.01){
            trans_z = -5 * error_angle + -10 * D_angle;
          }else{
            trans_z = 0;
          }

          std::cout << "x velocity: " << trans_x << std::endl;
          std::cout << "z velocity: " << trans_z << std::endl;
          std::cout << "heading: " << ori_z << std::endl;
          std::cout << "Distance: " << scan_middle << std::endl;


          base_cmd.linear.x = trans_x;
          base_cmd.angular.z = trans_z;
          linear_velocity.data = trans_x;
          angular_velocity.data = trans_z;
          linear_error.data = error_forward;
          angular_error.data = error_angle;

          vel_pub.publish(base_cmd);
          error_forward_pub.publish(linear_error);
          error_angle_pub.publish(angular_error);
          control_signal_forward_pub.publish(linear_velocity);
          control_signal_angle_pub.publish(angular_velocity);

        }

        void spin(){
            ros::Rate loop_rate(1.0 / dt);
            while (ros::ok()) {
                ros::spinOnce();
                loop_rate.sleep();
            }
        }
};



int main(int argc, char** argv){
    ros::init(argc, argv, "navigator");
    ros::NodeHandle nh;
    BotController bc(nh);

    BotController *control;
    BotController temp_control(nh);
    control = &temp_control;
    control->spin();

    ros::spin();
    return 0;
}
