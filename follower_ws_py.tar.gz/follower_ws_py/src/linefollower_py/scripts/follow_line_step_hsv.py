#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from pid_control import PID

class MoveKobuki(object):

    def __init__(self):

        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.last_cmdvel_command = Twist()
        self._cmdvel_pub_rate = rospy.Rate(10)
        self.shutdown_detected = False

    def move_robot(self, twist_object):
        self.cmd_vel_pub.publish(twist_object)

    def clean_class(self):
        # Stop Robot
        twist_object = Twist()
        twist_object.angular.z = 0.0
        self.move_robot(twist_object)
        self.shutdown_detected = True

class LineFollower(object):

    def __init__(self):

        self.bridge_object = CvBridge()
        self.image_sub = rospy.Subscriber("/mybot/camera1/image_raw",Image,self.camera_callback)
        self.movekobuki_object = MoveKobuki()
        # We set init values to ideal case where we detect it just ahead
        setPoint_value = 0.0
        state_value = 0.0
        self.pid_object = PID(init_setPoint_value = setPoint_value, init_state = state_value)
        # global I_error_x
        # global D_error_x
        # global error_x_prev
        # global error_x
        # I_error_x = 0
        # D_error_x = 0
        # error_x_prev = 0
        # error_x = 0

    def camera_callback(self,data):

        # global I_error_x
        # global D_error_x
        # global error_x_prev
        # global error_x
        #
        # error_x_prev = error_x


        try:
            # We select bgr8 because its the OpneCV encoding by default
            cv_image = self.bridge_object.imgmsg_to_cv2(data, desired_encoding="bgr8")
        except CvBridgeError as e:
            print(e)

        # We get image dimensions and crop the parts of the image we don't need
        # Bear in mind that because the first value of the image matrix is start and second value is down limit.
        # Select the limits so that it gets the line not too close and not too far, and the minimum portion possible
        # To make process faster.
        height, width, channels = cv_image.shape
        descentre = 100
        rows_to_watch = 20
        crop_img = cv_image[(height)/2+descentre:(height)/2+(descentre+rows_to_watch)][1:width]

        # Convert from RGB to HSV
        hsv = cv2.cvtColor(crop_img, cv2.COLOR_BGR2HSV)

        # Define the Yellow Colour in HSV
        lower_yellow = np.array([20,100,100])
        upper_yellow = np.array([50,255,255])

        # Threshold the HSV image to get only yellow colors
        mask = cv2.inRange(hsv, lower_yellow, upper_yellow)

        # Calculate centroid of the blob of binary image using ImageMoments
        m = cv2.moments(mask, False)
        try:
            cx, cy = m['m10']/m['m00'], m['m01']/m['m00']
            detect = 1
            rospy.loginfo("DETECT SOMETHING!!!")
        except ZeroDivisionError:
            cy, cx = height/2, width/2
            detect = 0
            rospy.loginfo("DETECT NOTHING... SEARCHING...")

        # Bitwise-AND mask and original image
        res = cv2.bitwise_and(crop_img, crop_img, mask= mask)


        # Draw the centroid in the resultut image
        # cv2.circle(img, center, radius, color[, thickness[, lineType[, shift]]])
        cv2.circle(res,(int(cx), int(cy)), 10,(0,0,255),-1)

        cv2.imshow("Original", cv_image)
        cv2.imshow("HSV", hsv)
        cv2.imshow("MASK", mask)
        cv2.imshow("RES", res)

        cv2.waitKey(1)



        if detect == 1:
            setPoint_value = width/2
            self.pid_object.setpoint_update(value=setPoint_value)
            # error_x = cx - width / 2
            # I_error_x += 0.1 * error_x;
            # D_error_x = error_x_prev - error_x
            # rospy.loginfo("Error now is: %d", error_x)
            self.pid_object.state_update(value=cx)
            effort_value = self.pid_object.get_control_effort()
            rospy.loginfo("Set Value=="+str(setPoint_value))
            rospy.loginfo("State Value=="+str(cx))
            rospy.loginfo("Effort Value=="+str(effort_value))
            twist_object = Twist()
            twist_object.linear.x = 0.15
            angular_effort_value = effort_value / 100
            rospy.loginfo("Effort Value=="+str(angular_effort_value))
            twist_object.angular.z = angular_effort_value
            # Make it start turning
            self.movekobuki_object.move_robot(twist_object)
        elif detect == 0:
            twist_object = Twist()
            twist_object.linear.x = 0
            twist_object.angular.z = 0.25
            # Make it start searching
            self.movekobuki_object.move_robot(twist_object)


    def clean_up(self):
        self.movekobuki_object.clean_class()
        cv2.destroyAllWindows()



def main():
    rospy.init_node('line_following_node', anonymous=True)


    line_follower_object = LineFollower()

    rate = rospy.Rate(10)
    ctrl_c = False
    def shutdownhook():
        # works better than the rospy.is_shut_down()
        line_follower_object.clean_up()
        rospy.loginfo("shutdown time!")
        ctrl_c = True

    rospy.on_shutdown(shutdownhook)

    while not ctrl_c:
        rate.sleep()



if __name__ == '__main__':
    main()
