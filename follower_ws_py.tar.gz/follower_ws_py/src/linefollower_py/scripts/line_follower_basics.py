#!/usr/bin/env python
import roslib
import sys
import rospy
import numpy as np
import cv2
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image

class LineFollwer(object):

    def __init__(self):

        self.bridge_object = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw", Image, self.camera_callback)
        # self.movekobuki_object = MoveKobuki()

    def camera_callback(self, data):
        try:
            cv_image = self.bridge_object.imgmsg_to_cv2(data, desired_encoding="bgr8")
        except CvBridgeError as e:
            print(e)

        # Get image dimensions and crop the parts of the image we don't need
        height, width, channels = cv_image.shape
        descentre = 160
        rows_to_watch = 20
        crop_img = cv_image[(height)/2+descentre:(height)/2+(descentre+rows_to_watch)][1:width]

        # Convert from RGB to HSV
        hsv = cv2.cvtColor(crop_img, cv2.COLOR_BGR2HSV)

        # Define the yellow color in HSV, you can find the range at: https://www.tydac.ch/color/
        lower_yellow = np.array([20,100,100])
        upper_yellow = np.array([50,255,255])

        # Threshold the HSV image to get only yellow color
        mask = cv2.inRange(hsv, lower_yellow, upper_yellow)

        # Bitwise-AND mask and original image
        res = cv2.bitwise_and(crop_img, crop_img, mask=mask)

        # Calculate the centroid of the blob of binary image using ImageMoments
        m = cv2.moments(mask, False)
        try:
            cx, cy = m['m10']/m['m00'], m['m01']/m['m00']
        except ZeroDivisionError:
            cx, cy = height/2, width/2

        # Draw the centroid in the resultut image
        cv2.circle(res, (int(cx), int(cy)), 10, (0,0,255), -1)

        cv2.imshow("Original", cv_image)
        cv2.imshow("HSV", hsv)
        cv2.imshow("MASK", mask)
        cv2.imshow("RES", res)

        cv2.waitKey(1)

        # Calculate the error
        error_x = cx - width/2
        twist_object = Twist()
        twist_object.linear.x = 0.2
        twist_object.angular.z = -error_x /100
        rospy.loginfo('ANGULAR VALUE SENT ===> ' + str(twist_object.angular.z))
        # Make the robot move
        # self.movekobuki_object.move_robot(twist_object)

        def clean_up(self):
            # self.movekobuki_object.clean_class()
            cv2.destroyAllWindows()

def main():
    rospy.init_node('line_following_node', anonymous=True)

    line_follower_object = LineFollwer()

    rate = rospy.Rate(5)
    ctrl_c = False

    def shutdownhook():
        # This will be working better than the rospy.is_shut_down()
        line_follower_object.clean_up()
        rospy.loginfo("SHUTDOWN TIME!")
        ctrl_c = True

    rospy.on_shutdown(shutdownhook)

    while not ctrl_c:
        rate.sleep()

if __name__ == '__main__':
    main()
